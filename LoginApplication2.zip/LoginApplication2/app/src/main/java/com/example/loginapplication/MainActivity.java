package com.example.loginapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private MaterialButton loginbutton;
    private MaterialButton registerbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        TextView username = findViewById(R.id.username);
        TextView password = findViewById(R.id.password);

        loginbutton = (MaterialButton) findViewById(R.id.loginbutton);
        registerbutton = (MaterialButton) findViewById(R.id.registerbutton);

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
                /*
                if(username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Login Unsuccessful. Please Try Again", Toast.LENGTH_SHORT).show();
                }
                */
            }
        });

        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToRegister();
            }
        });
    }

    public void login() {

        //**********SQL LOGIN CHECK ABOVE********************************
        if (findViewById(R.id.username) != null && findViewById(R.id.password) != null) {
            Intent intent = new Intent(this, Grid.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
        }
    }

    public void goToRegister() {
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
    }
}