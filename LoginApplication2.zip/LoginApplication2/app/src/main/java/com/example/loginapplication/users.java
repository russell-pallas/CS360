package com.example.loginapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class users extends SQLiteOpenHelper {

    public users(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    private static final class UserTable {
        private static final String TABLE = "Users";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "Username";
        private static final String COL_PASSWORD = "Password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + users.UserTable.TABLE + " (" +
                users.UserTable.COL_ID + " integer primary key autoincrement, " +
                users.UserTable.COL_NAME + " text, " +
                users.UserTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + users.UserTable.TABLE);
        onCreate(db);
    }

}
