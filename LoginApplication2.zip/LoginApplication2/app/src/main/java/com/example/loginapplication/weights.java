package com.example.loginapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class weights extends SQLiteOpenHelper {

    public weights(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final String DATABASE_NAME = "weight.db";
    private static final int VERSION = 1;

    private static final class WeightTable {
        private static final String TABLE = "Weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "Date";
        private static final String COL_WEIGHT = "Weight";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer primary key autoincrement, " +
                WeightTable.COL_DATE + " text, " +
                WeightTable.COL_WEIGHT + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }
}
